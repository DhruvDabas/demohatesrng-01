% multi(N1, N2, R) - R is the product of N1 and N2

multi(N1, N2, R) :-
    R is N1 * N2.

