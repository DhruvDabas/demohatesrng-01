% Check if an element is in the list
memb(X, [X|_]).  % X is the head
memb(X, [_|T]) :-  % Check the tail
    memb(X, T).

