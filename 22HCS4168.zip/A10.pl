% Grammar rules
s --> np, vp.

np --> det, n.

vp --> v.
vp --> v, np.

% Lexical rules
det --> [the].

n --> [teacher].
n --> [student].

v --> [scolds].

