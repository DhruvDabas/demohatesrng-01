% Define the directed edges
edge(p, q).
edge(q, r).
edge(q, s).
edge(s, t).

% A route exists from X to Y if there is a direct edge
route(X, Y) :- 
    edge(X, Y).

% A route exists from X to Y if there is an edge from X to some Z, and a route from Z to Y
route(X, Y) :- 
    edge(X, Z),
    route(Z, Y).

