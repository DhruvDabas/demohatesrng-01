% Directed graph edges
edge('p', 'q').
edge('q', 'r').
edge('q', 's').
edge('s', 't').

% Route exists directly if there is a direct edge
route(A, B) :- 
    edge(A, B).

% Route exists if there is an edge from A to X and a route from X to B
route(A, B) :-
    edge(A, X),
    route(X, B), 
    !.  % Cut to stop re-initialization of variables

