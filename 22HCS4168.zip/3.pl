% base case: n = 1 then skip the head and return the tail
delete(1, [_|T], T).

% recursion: N > 1 then keep the head and recurse on the tail
delete(N, [H|T], [H|R]) :-
    N > 1,
    N1 is N - 1,
    delete(N1, T, R).

