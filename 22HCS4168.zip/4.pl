% sum(A, B, Result) - computes Result as the sum of A and B
sum(A, B, Result) :-
    Result is A + B.

