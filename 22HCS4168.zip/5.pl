% max(X, Y, M) - M is the maximum of X and Y
max(X, Y, X) :- X >= Y.
max(X, Y, Y) :- X < Y.

