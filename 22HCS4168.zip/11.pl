% 11. Sum of elements in a list
sumlist([], 0).  % Base case: sum of an empty list is 0
sumlist([H|T], S) :-
    sumlist(T, S1),  % Recursive call
    S is H + S1.  % Add the head to the sum of the tail
