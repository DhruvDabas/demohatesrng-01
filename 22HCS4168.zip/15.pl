% 15. Delete the Nth element from a list
delete(1, [H|T], T).  % Base case: delete the first element
delete(N, [H|T], [H|R]) :-
    N > 1,
    N1 is N - 1,
    delete(N1, T, R).

