% Define the directed edges
edge(e, f).
edge(g, h).
edge(i, j).
edge(k, l).

% Route exists if there is a direct edge
route(X, Y) :- 
    edge(X, Y).

% Route exists if there is an edge from X to some Z, and a route from Z to Y
route(X, Y) :- 
    edge(X, Z),
    route(Z, Y).

