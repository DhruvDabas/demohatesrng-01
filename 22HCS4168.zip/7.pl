% nth_fibonacci(N, Term) - Term is the Nth term in the Fibonacci sequence

nth_fibonacci(0, 0).
nth_fibonacci(1, 1).
nth_fibonacci(N, Term) :-
    N > 1,
    N1 is N - 1,
    N2 is N - 2,
    nth_fibonacci(N1, Term1),
    nth_fibonacci(N2, Term2),
    Term is Term1 + Term2.

