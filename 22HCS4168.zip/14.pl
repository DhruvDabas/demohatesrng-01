% 14. Insert an item at the Nth position in the list
insert(I, 1, L, [I|L]).  % Base case: insert at the start
insert(I, N, [Start|End], [Start|Rest]) :-
    N > 1,  % If N > 1, continue the recursion
    N1 is N - 1,
    insert(I, N1, End, Rest).
