% power(Num, Pow, Ans) - Ans is Num raised to the power Pow

power(_, 0, 1).  % Any number to the power 0 is 1
power(Num, Pow, Ans) :-
    Pow > 0,
    Pow1 is Pow - 1,
    power(Num, Pow1, Ans1),
    Ans is Num * Ans1.

