% 12. Check if the length of the list is even
evenlength(L) :-
    length(L, N),
    0 is N mod 2.  % Even length if remainder by 2=0

