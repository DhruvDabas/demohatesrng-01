% 13. Check if the length of the list is odd
oddlength(L) :-
    length(L, N),
    1 is N mod 2.  % Odd length if remainder of division by 2 is 1

