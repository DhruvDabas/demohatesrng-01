% --- Facts ---
parent(mark, mary).
parent(mark, james).
parent(lisa, mary).
parent(lisa, ben).
parent(mary, anna).
parent(mary, angela).
parent(ben, charlie).

female(mary).
female(susan).
female(anna).
female(angela).  
male(john).
male(james).
male(ben).
male(charlie).

% --- Rules ---

% Sibling: share at least one parent and are not the same person
sibling(X, Y) :-
    parent(Z, X),
    parent(Z, Y),
    X \= Y.

% Brother: male sibling
brother(X, Y) :-
    sibling(X, Y),
    male(X).

% Sister: female sibling
sister(X, Y) :-
    sibling(X, Y),
    female(X).

% Mother: female parent
mother(X, Y) :-
    parent(X, Y),
    female(X).

% Father: male parent
father(X, Y) :-
    parent(X, Y),
    male(X).

% Uncle: brother of a parent
uncle(X, Y) :-
    parent(Z, Y),
    brother(X, Z).

% Aunt: sister of a parent
aunt(X, Y) :-
    parent(Z, Y),
    sister(X, Z).

% Cousin: child of an aunt or uncle
cousin(X, Y) :-
    parent(PX, X),
    parent(PY, Y),
    sibling(PX, PY),
    X \= Y.

% Grandparent: parent of a parent
grandparent(X, Y) :-
    parent(X, Z),
    parent(Z, Y).

