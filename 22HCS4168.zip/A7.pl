% Grammar rules
s --> np, vp.

np --> det, n.

vp --> v.
vp --> v, np.

% Lexical rules
det --> [the].

n --> [bird].
n --> [worm].

v --> [sees].

