% Define the directed edges of the graph
edge(j, k).
edge(l, m).
edge(n, o).
edge(p, q).

% A route exists from X to Y if there is a direct edge
route(X, Y) :- 
    edge(X, Y).

% A route exists from X to Y if there is a path from X to some Z, and from Z to Y
route(X, Y) :- 
    edge(X, Z),
    route(Z, Y).

