% conc(L1, L2, L3)
% L3 is the result of appending list L2 to the end of list L1.

% base case: appending any list to an empty list yields that list
conc([], L, L).

% recursion build the result list by keeping the head of L1
conc([Head|Tail], L2, [Head|Result]) :-
    conc(Tail, L2, Result).

